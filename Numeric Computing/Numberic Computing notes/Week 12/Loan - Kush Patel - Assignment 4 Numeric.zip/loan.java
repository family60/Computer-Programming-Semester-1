
public class loan {
	
	private double loanAmount;
	private double rate;
	private double monthlyInstallment;
	
	public double getLoanAmount() {
		return loanAmount;
	}
	
	public double getRate() {
		return rate;
	}
	
	public double getMonthlyInstallment() {
		return monthlyInstallment;
	}
	
	public void setLoanAmount(double l) {
		loanAmount = l;
	}
	
	public void setRate(double r) {
		rate = r;
	}
	
	public void setMonthlyInstallment(double mi) {
		monthlyInstallment = mi;
	}
	
	public loan(double l, double r, double mi) {
		loanAmount = l;
		rate = r;
		monthlyInstallment = mi;
	}
	
	public void printLoanRepaymentSchedule() {
		int counter = 0;
		double originalLoanAmount = loanAmount;
		double interestPaid = 0;
		rate = rate/100/12;
		double totalInterestPaid = 0;
		for (int c = 1; loanAmount >= monthlyInstallment; c++) {
			
			if (c == 1) {
				System.out.println("|Payment Number|Balance Before Payment|Amount Paid|Interest Paid|Principle Repaid|Balance After Payment|");
			}
			
			System.out.print("|             " + c);
			
			System.out.printf("|                " + "%.2f",loanAmount);
			
			System.out.printf("|      " + "%.2f",monthlyInstallment);
			interestPaid = (loanAmount * rate);
			totalInterestPaid = interestPaid + totalInterestPaid;
			
			System.out.printf("|         " + "%.2f",interestPaid);
			
			System.out.printf("|           " + "%.2f",(monthlyInstallment - (loanAmount * (rate))));
			
			loanAmount = (loanAmount - monthlyInstallment + (loanAmount * (rate)));
			System.out.printf("|               " + "%.2f",loanAmount);
			System.out.println("|");
			counter = c;
			}
		
		System.out.print("|             " + (counter + 1));
		
		System.out.printf("|                " + "%.2f",loanAmount);
		
		interestPaid = (loanAmount * rate);
		System.out.printf("|      " +  "%.2f",(loanAmount + interestPaid));
		totalInterestPaid = interestPaid + totalInterestPaid;
		
		System.out.printf("|         " + "%.2f",interestPaid);
		
		System.out.printf("|           " + "%.2f",loanAmount);
		
		System.out.printf("|               " + "%.2f",0.00);
		
		System.out.println("|");
		
		System.out.printf("total                                       " + "%.2f",(originalLoanAmount + totalInterestPaid));
		System.out.printf("|         " + "%.2f",totalInterestPaid );
		System.out.printf("|          " + "%.2f", originalLoanAmount);
		System.out.println("|");
	}
	
}
