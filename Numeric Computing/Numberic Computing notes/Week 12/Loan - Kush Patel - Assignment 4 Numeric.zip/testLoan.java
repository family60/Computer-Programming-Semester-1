
public class testLoan {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		loan l1 = new loan(25000,5.99,500);
		l1.printLoanRepaymentSchedule();
		
	}

}
