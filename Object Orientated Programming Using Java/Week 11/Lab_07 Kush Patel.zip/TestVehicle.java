public class TestVehicle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ChildCar c1 = new ChildCar("Ford", "Fusion", 2019, "abc" ,"Hybrid", 5);
		System.out.println(c1.toString());
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
