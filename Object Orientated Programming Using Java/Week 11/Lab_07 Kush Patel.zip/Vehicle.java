
public class Vehicle {
	
	private String make;
	private String model;
	private int year;
	private String VINnumber;
	
	public String getMake() {
		return make;
	}
	public void setMake(String m) {
		make = m;
	}
	
	public String getModel() {
		return model;
	}
	public void setModel(String mo) {
		model = mo;
	}
	
	public int getYear() {
		return year;
	}
	public void setYear(int y) {
		year = y;
	}
	
	public String getVINnumber() {
		return VINnumber;
	}
	public void setVINnumber(String vn) {
		VINnumber = vn;
	}
	
	public Vehicle() {
		make = "";
		model = "";
		year = 0;
		VINnumber = "";
	}
	
	public Vehicle(String m, String mo, int y, String vn) {
		make = m;
		model = mo;
		year = y;
		VINnumber = vn;
	}
	
	public String toString() {
		return make + " " + model + " " + year + " " + VINnumber;
	}
	
}






