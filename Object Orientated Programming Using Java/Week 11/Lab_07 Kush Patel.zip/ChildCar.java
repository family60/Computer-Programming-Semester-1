public class ChildCar extends Vehicle{
	
	private  String carType;
	private int passengers;
	
	public String getCarType() {
		return carType;
	}
	public void setCarType(String ct) {
		carType = ct;
	}
	
	public int getPassengers() {
		return passengers;
	}
	public void setPassengers(int p) {
		passengers = p;
	}
	
	public ChildCar() {
		
	}
	
	public ChildCar(String m, String mo, int y, String vn, String ct, int p) {
		
		super(m,mo,y,vn);
		carType = ct;
		passengers = p;

	}
	
	@Override
	public String toString() {
		return super.toString() + " " + carType + " " + passengers;
	}
	
}
