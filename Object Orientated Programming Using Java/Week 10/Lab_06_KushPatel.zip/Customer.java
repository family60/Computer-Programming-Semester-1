package lab_06;

public class Customer {
		
	private String customerName;
	private int customerNumber;
		
	Customer(){
			
		customerName = "";
		customerNumber = 0;
		
	}
		
	Customer(String name, int number){
			
		customerName = name;
		customerNumber = number;
			
	}
		
	public String getCustomerName() {
			
		return customerName;
			
	}
		
	public int getCustomerNumber() {
			
		return customerNumber;
			
	}
		
	public void setCustomerName(String name) {
	
		customerName = name;
	
	}
		
	public void setCustomerNumber(int number) {
			
		customerNumber = number;
			
	}
		
	public double calculateTotalAmount(double amount1) {
			
		return (1.13*amount1);
			
	}
	public double calculateTotalAmount(double amount1, double amount2) {
			
		return (amount1 + amount2) * 1.13;
			
	}
		
	public void grandTotal(double totalAmount) {
			
		System.out.println(totalAmount + 4.99);
		
	}
		
}