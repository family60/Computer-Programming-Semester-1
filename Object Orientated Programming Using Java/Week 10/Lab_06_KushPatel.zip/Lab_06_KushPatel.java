package lab_06;
import java.util.*;

public class Lab_06_KushPatel {
	
	//@author Kush Patel
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in);
		String cname;
		int cnumber, items;
		double amount1, amount2, totalAmount;
		
		Customer c1 = new Customer();
		String c1name = "John Doe";
		int c1number = 585581;
		c1.setCustomerName(c1name);
		c1.setCustomerNumber(c1number);
		System.out.println(c1.getCustomerName());
		System.out.println(c1.getCustomerNumber());
		
		
		String c3name = "John Doe";
		int c3number = 585581;
		Customer c3 = new Customer(c3name, c3number);
		System.out.println(c3.getCustomerName());
		System.out.println(c3.getCustomerNumber());
		
		
		System.out.println("Enter customer name");
		cname = input.nextLine();
		System.out.println("Enter customer number");
		cnumber = input.nextInt();
		
		Customer c2 = new Customer(cname,cnumber);
		
		System.out.println("How many items do you wish to buy? 1 or 2?");
		items = input.nextInt();
		
		
		if (items == 1) {
			
			System.out.println("Enter the cost of item 1");
			amount1 = input.nextDouble();
			System.out.println("Total amount with tax is: " + c2.calculateTotalAmount(amount1));
			totalAmount = c2.calculateTotalAmount(amount1);
			System.out.println(c2.getCustomerName() + " " + c2.getCustomerNumber() + " has a grand total (with 4.99 shipping) of: ");
			c2.grandTotal(totalAmount);
			
		}else if (items == 2) {
		
			System.out.println("Enter the cost of item 1");
			amount1 = input.nextDouble();
			System.out.println("Enter the cost of item 2");
			amount2 = input.nextDouble();
			System.out.println("Total amount with tax is: " + c2.calculateTotalAmount(amount1, amount2));
			totalAmount = c2.calculateTotalAmount(amount1, amount2);
			System.out.println(c2.getCustomerName() + " " + c2.getCustomerNumber() + "has a grand total (with 4.99 shipping) of: ");
			c2.grandTotal(totalAmount);
			
		}
		
	}

}
