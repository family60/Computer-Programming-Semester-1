import java.util.*;
public class TestBMI {

// @author Kush Patel
//this program takes in input from the user (height and weight)
//then calculates their BMI and outputs it as well as their health based on BMI categories

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner input = new Scanner(System.in);
		
		BMI bmi1 = new BMI();
		
		System.out.println("Enter height in inches");
		double inches = input.nextDouble();
		
		System.out.println("Enter weight in pounds");
		double pounds = input.nextDouble();
		
		BMI bmi2 = new BMI(inches, pounds);
		
		double BMI = bmi2.calculateBMI(inches, pounds);
		bmi2.result(BMI);
		
	}
}
