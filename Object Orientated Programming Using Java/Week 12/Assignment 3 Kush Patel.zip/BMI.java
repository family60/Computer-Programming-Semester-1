
public class BMI {
	
	private double height;
	private double weight;
	//encapsulated instance fields for height and weight
	
	public BMI() {//default constructor
		
	}
	
	public BMI(double h, double w) {//constructor with two parameters
		height = h;
		weight = w;
	}
	
	
	public double getHeight() {//accessor for height
		return height;
	}
	
	public void setHeight(double h) {//mutator for height
		height = h;
	}
	
	public double getWeight() {//accessor for weight
		return weight;
	}
	
	public void setWeight(double w) {//mutator for weight
		weight = w;
	}
	
	public double convert2KG(double wp) {//method that receives weight in pounds, converts it to kg and then returns that value
		weight = wp*0.453;
		return weight;
	}
	
	public double convert2m(double hi) {//method that receives height in inches, converts it to meters and then returns that value
		height = hi*0.0254;
		return height;
	}
	
	public double calculateBMI(double hi, double wp) {//method that receives height and weight, calls other methods to convert it and calculates and returns the BMI
		height = convert2m(hi);
		weight = convert2KG(wp);
		return weight / (height*height);
	}
	
	public void result(double BMI) {//method that receives BMI value and prints the appropriate message
		System.out.println(BMI);
		if (BMI < 18.5) {
			System.out.println("Underweight");
		}else if ((BMI >= 18.5) && (BMI <= 24.9)) {
			System.out.println("Normal");
		}else if ((BMI >= 25) && (BMI <= 29.9)) {
			System.out.println("Overweight");
		}else {
			System.out.println("Obese");
		}
	}
	
}
