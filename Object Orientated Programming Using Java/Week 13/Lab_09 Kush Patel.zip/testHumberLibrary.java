package lab10;

public class testHumberLibrary {

	public static void main(String[] args) {
		
		TextBooks tb1 = new TextBooks();
		Multimedia mm1 = new Multimedia();
		tb1.printDetails();
		mm1.printDetails();
	 
		
	}

}
