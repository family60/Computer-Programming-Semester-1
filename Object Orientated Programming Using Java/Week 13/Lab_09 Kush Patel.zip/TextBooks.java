package lab10;

public class TextBooks extends HumberLibrary{
	
	private String publisher = "Game Freak";
	private String author = "Kush Patel";
	
	
	@Override
	public void printDetails() {
		System.out.println(getID());
		System.out.println(getTitle());
		System.out.println(publisher);
		System.out.println(author);
	}

}
