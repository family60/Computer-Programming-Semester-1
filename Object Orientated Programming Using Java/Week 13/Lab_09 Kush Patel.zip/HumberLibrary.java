package lab10;

public abstract class HumberLibrary {
	
	private int id = 585581;
	private String title = "Hello World";
	private final String address = "Fourth Floor";
	
	
	public int getID() {
		return id;
	}
	public void setID(int x) {
		id = x;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String t) {
		title = t;
	}
	public String getAddress() {
		return address;
	}
	
	
	
	public abstract void printDetails();
	
	public final void printLibraryAddress() {
		System.out.println(address);
	}
	
	
	
	
}
