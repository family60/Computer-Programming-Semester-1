package lab10;

public class Multimedia extends HumberLibrary{
	
	private int releaseDate = 2019;
	private int length = 5;
	
	
	
	@Override
	public void printDetails() {
		System.out.println(getID());
		System.out.println(getTitle());
		System.out.println(releaseDate);
		System.out.println(length);
		
	}

}
