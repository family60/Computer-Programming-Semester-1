package Lab5;
import java.util.*;
//@author : Kush Patel
public class Lab05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Employee e1 = new Employee();
		Employee e2 = new Employee(585581,500,"Kush","Patel");
		System.out.println("Enter number of hours worked");
		int hours = input.nextInt();
		int netSalary = e2.CalculateNetSalary(500, hours);
		System.out.println("Net Salary for Employee 2 is: " + netSalary);
		System.out.println("count : " +Employee.count);
	
	}

}
