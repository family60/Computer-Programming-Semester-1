package Lab5;


	
public  class Employee{
	int EmployeeId, baseSalary;
	String firstName, lastName;
	static int count;
		
	Employee(){
		EmployeeId = 1;
		firstName = "aa";
		lastName = "aa";
		baseSalary = 0;
		count++;
	}
		
	Employee(int id, int salary, String first, String last){
		EmployeeId = id;
		baseSalary = salary;
		firstName = first;
		lastName = last;
		count++;
	}
		
	public int CalculateNetSalary(int base, int hours) {
		int netSalary = 0;
			
		if(base < 1000) {
			netSalary = base + (100*hours);
		}else {
			netSalary = base + (70*hours);
		}
			
		return netSalary;
	}
		
		
		
}


