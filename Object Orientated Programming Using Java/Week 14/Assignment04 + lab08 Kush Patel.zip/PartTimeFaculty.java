//Kush Patel
//Child Class Part Time Faculty
public class PartTimeFaculty extends Faculty{
	
	private double rate;
	
	public PartTimeFaculty() {
		
	}
	
	public PartTimeFaculty(String f, String l, String c, double r) {
		super.setFirstName(f);
		super.setLastName(l);
		super.setCourse(c);
		rate = r;
	}
	
	public double getRate() {
		return rate;
	}
	
	public void setRate(double r) {
		rate = r;
	}
	
	@Override
	public String toString() {
		return "First Name: " + super.getFirstName() + "  Last Name: " + super.getLastName() + "  Course: " + super.getCourse() + "  Pay Rate: $" + rate;
	}
	
}
