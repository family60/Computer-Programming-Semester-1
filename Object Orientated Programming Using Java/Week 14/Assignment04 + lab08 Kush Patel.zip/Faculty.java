//Kush Patel
//Child Class Faculty
public class Faculty extends Employee{
	
	private String course;
	
	public Faculty() {
		
	}
	
	public Faculty(String f, String l, String c) {
		super.setFirstName(f);
		super.setLastName(l);
		course = c;
	}
	
	public String getCourse() {
		return course;
	}
	
	public void setCourse(String c) {
		course = c;
	}
	
	@Override
	public String toString() {
		return "First Name: " + super.getFirstName() + "  Last Name: " + super.getLastName() + "  Course: " + course;
	}
}
