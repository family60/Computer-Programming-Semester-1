//Kush Patel
//Main Class TestEmployee
public class TestEmployee {

	public static void main(String[] args) {
		
		Employee e1 = new Employee("Kush","Patel");
		System.out.println("Employee - " + e1.toString());
		
		Faculty f1 = new Faculty("Kush", "Patel", "Object-Orientated Programming using Java");
		System.out.println("Faculty - " + f1.toString());
		
		Staff s1 = new Staff("Kush", "Patel", "Night");
		System.out.println("Staff - " + s1.toString());
		
		FullTimeFaculty ftf1 = new FullTimeFaculty("Kush", "Patel", "Object-Orientated Programming using Java", 80000);
		System.out.println("Full Time Faculty - " + ftf1.toString());
		
		PartTimeFaculty ptf1 = new PartTimeFaculty("Kush", "Patel", "Object-Orientated Programming using Java", 24.45);
		System.out.println("Part Time Faculty - " + ptf1.toString());
	}

}
