//Kush Patel
//Child Class Staff
public class Staff extends Employee{
	
	private String shift;
	
	public Staff() {
		
	}
	
	public Staff(String f, String l, String s) {
		super.setFirstName(f);
		super.setLastName(l);
		shift = s;
	}
	
	public String getString() {
		return shift;
	}
	
	public void setString(String s) {
		shift = s;
	}
	
	@Override
	public String toString() {
		return "First Name: " + super.getFirstName() + "  Last Name: " + super.getLastName() + "  Shift: " + shift;
	}
	
}
