//Kush Patel
//parent class
public class Employee {
	
	private String FName, LName;
	
	public Employee() {
		
	}
	
	public Employee(String fn, String ln) {
		FName = fn;
		LName = ln;
	}
	
	public String getFirstName() {
		return FName;
	}
	
	public String getLastName() {
		return LName;
	}
	
	public void setFirstName(String f) {
		FName = f;
	}
	
	public void setLastName(String l) {
		LName = l;
	}
	
	public String toString() {
		return "First Name: " + FName + "  Last Name: " + LName;
	}
}
