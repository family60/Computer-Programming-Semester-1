//Kush Patel
//Child Class Full Time Faculty
public class FullTimeFaculty extends Faculty{
	
	private double salary;
	
	public FullTimeFaculty() {
		
	}
	
	public FullTimeFaculty(String f, String l, String c, double s) {
		super.setFirstName(f);
		super.setLastName(l);
		super.setCourse(c);
		salary = s;
	}
	
	public double getSalary() {
		return salary;
	}
	
	public void setSalary(double s) {
		salary = s;
	}
	
	@Override
	public String toString() {
		return "First Name: " + super.getFirstName() + "  Last Name: " + super.getLastName() + "  Course: " + super.getCourse() + "  Salary: $" + salary;
	}
	
}
