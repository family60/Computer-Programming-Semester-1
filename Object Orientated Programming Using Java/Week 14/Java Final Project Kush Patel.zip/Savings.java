//Kush Patel
//Child class/subclass 
public class Savings extends Account{
	
	private double monthlyInterest;
	//instance field for monthly interest
	
	public double getMonthlyInterest() {//mutator for monthly interest
		return monthlyInterest*(2/1200);
	}
	
	public int withdrawAmount(double amount) {//checks if the amount the user wants to withdraw will put them in negative balance,
		//if it does then an error message will print, otherwise it will go through
		
		if (((getBalance() - amount) <= 0) || (amount < 0)) {
			System.out.println("There is not enough balance in your account");
			return 1;
		}else {
			double newBalance = getBalance() - amount;
			setBalance(newBalance);
			return 2;
		}
	
	}
	
	public int depositAmount(double amount) {//checks if the user entered a negative deposit amount, if so, an error will print, otherwise it will go through
		
		if (amount < 0) {
			System.out.println("You cannot deposit a negative amount of money");
			return 1;
		}else {
			double newBalance = getBalance() + amount;
			setBalance(newBalance);
			return 2;
		}
	}
	
	
	
}
