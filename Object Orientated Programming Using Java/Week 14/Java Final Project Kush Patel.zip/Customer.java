//Kush Patel
public class Customer {
	
	private String FName;
	private String LName;
	private String Email;
	private String phoneNumber;
	private int customerID;
	//instance fields for first name, last name, E-mail address, phone number and customer ID
	
	public String getFName() {//accessor for first name
		return FName;
	}
	
	public String getLName() {//accessor for last name
		return LName;
	}
	
	public String getEmail() {//accessor for E-mail address
		return Email;
	}
	public String getPhoneNumber() {//accessor for phone number
		return phoneNumber;
	}
	
	public int getCustomerID() {//accessor for customer ID
		return customerID;
	}
	
	public void setFName(String first) {//mutator for first name
		FName = first;
	}
	
	public void setLName(String last) {//mutator for last name
		LName = last;
	}
	
	public void setEmail(String email) {//mutator for E-mail address
		Email = email;
	}
	
	public void setPhoneNumber(String pn) {//mutator for phone number
		phoneNumber = pn;
	}
	
	public void setCustomerID(int CID) {//mutator for customer ID
		customerID = CID;
	}
	
	public void printInfo() {//will output all of the customers details
		
		System.out.println(FName);
		System.out.println(LName);
		System.out.println(Email);
		System.out.println(phoneNumber);
		System.out.println(customerID);
		
	}
	
}
