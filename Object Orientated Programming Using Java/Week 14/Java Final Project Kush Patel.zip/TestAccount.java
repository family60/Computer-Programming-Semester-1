//Kush Patel
//Test Account class (Main class)
import java.util.*;
public class TestAccount {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		String firstName, lastName, Email, phoneNumber, accountType = "";
		int customerID, choice2;
		boolean properBalance = false, choice1 = false, quit = false, withdrawCheck = false, depositCheck = false;
		double balance = 1, withdraw = 0, deposit = 0;
		
		
		System.out.println("Enter first name");
		firstName = input.nextLine();
		System.out.println("Enter last name");
		lastName = input.nextLine();
		System.out.println("Enter E-mail address");
		Email = input.nextLine();
		System.out.println("Enter phone number");
		phoneNumber = input.nextLine();
		System.out.println("Enter customer ID");
		customerID = input.nextInt();
		//getting customer details from user
		
		Customer c1 = new Customer();
		c1.setFName(firstName);
		c1.setLName(lastName);
		c1.setEmail(Email);
		c1.setPhoneNumber(phoneNumber);
		c1.setCustomerID(customerID);
		//setting the details that were entered
		
		while (properBalance == false) {//checking for valid balance value
			System.out.println("Enter Balance");
			balance = input.nextDouble();
			if (balance <= 0) {
				System.out.println("Invalid balance, try again (must be > 0)");
			}else {
				properBalance = true;
			}
		}
		
		while (choice1 == false) {//making the user choose between making a savings account and a checking account
			System.out.println("Enter what type of account you want to make. S for savings and C for checking");
			accountType = input.nextLine();
			if ((accountType.contentEquals("S")) || (accountType.contentEquals("C"))) {
				choice1 = true;
			}else {
				System.out.println("Please Enter S or C, nothing else");
			}
		}
		
		if (accountType.contentEquals("S")) {//while they have made a savings account, output menu to user, they can check balance, withdraw, deposit, print their details or end the program
			Savings s1 = new Savings();
			s1.setCID(customerID);
			s1.setBalance(balance);
			while (quit == false) {
				System.out.println("Enter a choice: \n1) Check Balance\n2) Withdraw\n3) Deposit\n4) Print customer detail\n5) Quit");
				choice2 = input.nextInt();
				if (choice2 == 1) {
					System.out.println("Balance is: $" + s1.getBalance());
				}else if (choice2 == 2) {
					while (withdrawCheck == false) {
						System.out.println("Enter amount you want to withdraw");
						withdraw = input.nextDouble();
						if (s1.withdrawAmount(withdraw) == 2) {
							System.out.println("successful");
							withdrawCheck = true;
						}else if (s1.withdrawAmount(withdraw) == 1) {
							withdrawCheck = false;
						}
					}
					withdrawCheck = false;
				}else if (choice2 == 3) {
					while (depositCheck == false) {
						System.out.println("Enter amount you want to deposit");
						deposit = input.nextDouble();
						if (s1.depositAmount(deposit) == 2) {
							System.out.println("successful");
							depositCheck = true;
						}else if (s1.depositAmount(deposit) == 1) {
							depositCheck = false;
						}
					}
					depositCheck = false;
				}else if (choice2 == 4) {
					System.out.println("Here are your details");
					c1.printInfo();
				}else if (choice2 ==5) {
					quit = true;
				}
			}
			System.out.println("Thank you for using my program");
		}else if (accountType.contentEquals("C")) {//while they have made a checking account, output menu to user, they can check balance, withdraw, deposit, print their details or end the program
			Checking ch1 = new Checking();
			ch1.setCID(customerID);
			ch1.setBalance(balance);
			while (quit == false) {
				System.out.println("Enter a choice: \n1) Check Balance\n2) Withdraw\n3) Deposit\n4) Print customer detail\n5) Quit");
				choice2 = input.nextInt();
				if (choice2 == 1) {
					System.out.println("Balance is: $" + ch1.getBalance());
				}else if (choice2 == 2) {
					while (withdrawCheck == false) {
						System.out.println("Enter amount you want to withdraw");
						withdraw = input.nextDouble();
						if (ch1.withdrawAmount(withdraw) == 2) {
							System.out.println("successful");
							withdrawCheck = true;
						}else if (ch1.withdrawAmount(withdraw) == 1) {
							withdrawCheck = false;
						}
					}
					withdrawCheck = false;
				}else if (choice2 == 3) {
					while (depositCheck == false) {
						System.out.println("Enter amount you want to deposit");
						deposit = input.nextDouble();
						if (ch1.depositAmount(deposit) == 2) {
							System.out.println("successful");
							depositCheck = true;
						}else if (ch1.depositAmount(deposit) == 1) {
							depositCheck = false;
						}
					}
					depositCheck = false;
				}else if (choice2 == 4) {
					System.out.println("Here are your details");
					c1.printInfo();
				}else if (choice2 ==5) {
					quit = true;
				}
			}
			System.out.println("Thank you for using my program");
		}
		
		
		
	}

}
