//Kush Patel 
//parent class
public class Account {
	
	private int cId;
	private double balance;
	//instance fields for customer id and balance
	
	public Account() {//Constructor with no arguments (default constructor)
		cId = 0;
		balance = 0.0;
	}
	
	public Account(int c, double b) {//Constructor that receives customer id and balance and set them to the instance fields
		cId = c;
		
		if (b <= 0) {
			System.out.println("Invalid balance value, balance will be assigned to $1");
		}else {
			balance = b;
		}
	
	}
	
	public int getCID() {//Accessor for customer id
		return cId;
	}
	
	public void setCID(int c) {//mutator for customer id
		cId = c;
	}
	
	public double getBalance() {//accessor for balance
		return balance;
	}
	
	public void setBalance(double b) {//mutator for balance
		
		if (b <= 0) {//checks to see if what the user inputted is valid or not (<= 0 or not)
			System.out.println("Invalid balance value, try again with a value greater than $0");
		}else {//if input is valid, set b to balance
			balance = b;
		}
	
	}
	
}
